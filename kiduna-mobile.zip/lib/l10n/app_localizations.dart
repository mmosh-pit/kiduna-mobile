import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[Locale('en')];

  /// No description provided for @appName.
  ///
  /// In en, this message translates to:
  /// **'Kiduna'**
  String get appName;

  /// No description provided for @welcomeTo.
  ///
  /// In en, this message translates to:
  /// **'Welcome to {name}'**
  String welcomeTo(String name);

  /// No description provided for @baseProjectReady.
  ///
  /// In en, this message translates to:
  /// **'Base project ready. Start building features.'**
  String get baseProjectReady;

  /// No description provided for @ki.
  ///
  /// In en, this message translates to:
  /// **'Ki'**
  String get ki;

  /// No description provided for @inspect.
  ///
  /// In en, this message translates to:
  /// **'Inspect'**
  String get inspect;

  /// No description provided for @compute.
  ///
  /// In en, this message translates to:
  /// **'Compute'**
  String get compute;

  /// No description provided for @openResources.
  ///
  /// In en, this message translates to:
  /// **'Open Resources'**
  String get openResources;

  /// No description provided for @fieldFocus.
  ///
  /// In en, this message translates to:
  /// **'Field focus'**
  String get fieldFocus;

  /// No description provided for @possibleActions.
  ///
  /// In en, this message translates to:
  /// **'Possible Actions'**
  String get possibleActions;

  /// No description provided for @aFewActionsYouCanTakeNow.
  ///
  /// In en, this message translates to:
  /// **'A few Actions you can take now'**
  String get aFewActionsYouCanTakeNow;

  /// No description provided for @selectAnyFactToExploreItWithKi.
  ///
  /// In en, this message translates to:
  /// **'Select any fact to explore it with Ki.'**
  String get selectAnyFactToExploreItWithKi;

  /// No description provided for @messageKi.
  ///
  /// In en, this message translates to:
  /// **'Message Ki…'**
  String get messageKi;

  /// No description provided for @sendToKi.
  ///
  /// In en, this message translates to:
  /// **'Send to Ki'**
  String get sendToKi;

  /// No description provided for @startVoiceInput.
  ///
  /// In en, this message translates to:
  /// **'Start voice input'**
  String get startVoiceInput;

  /// No description provided for @prepareInvitation.
  ///
  /// In en, this message translates to:
  /// **'Prepare invitation'**
  String get prepareInvitation;

  /// No description provided for @nameYouUseForThem.
  ///
  /// In en, this message translates to:
  /// **'Name you use for them'**
  String get nameYouUseForThem;

  /// No description provided for @expiration.
  ///
  /// In en, this message translates to:
  /// **'Expiration'**
  String get expiration;

  /// No description provided for @proposedRole.
  ///
  /// In en, this message translates to:
  /// **'Proposed role'**
  String get proposedRole;

  /// No description provided for @notes.
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get notes;

  /// No description provided for @copyLink.
  ///
  /// In en, this message translates to:
  /// **'Copy link'**
  String get copyLink;

  /// No description provided for @copyCode.
  ///
  /// In en, this message translates to:
  /// **'Copy code'**
  String get copyCode;

  /// No description provided for @uniqueLink.
  ///
  /// In en, this message translates to:
  /// **'Unique link'**
  String get uniqueLink;

  /// No description provided for @kinshipCode.
  ///
  /// In en, this message translates to:
  /// **'Kinship Code'**
  String get kinshipCode;

  /// No description provided for @personalInvitation.
  ///
  /// In en, this message translates to:
  /// **'Personal invitation'**
  String get personalInvitation;

  /// No description provided for @realmName.
  ///
  /// In en, this message translates to:
  /// **'Realm name'**
  String get realmName;

  /// No description provided for @typeLabel.
  ///
  /// In en, this message translates to:
  /// **'Type'**
  String get typeLabel;

  /// No description provided for @purpose.
  ///
  /// In en, this message translates to:
  /// **'Purpose'**
  String get purpose;

  /// No description provided for @createRealmAction.
  ///
  /// In en, this message translates to:
  /// **'Create Realm'**
  String get createRealmAction;

  /// No description provided for @createOrganizationAction.
  ///
  /// In en, this message translates to:
  /// **'Create Organization'**
  String get createOrganizationAction;

  /// No description provided for @creating.
  ///
  /// In en, this message translates to:
  /// **'Creating…'**
  String get creating;

  /// No description provided for @organizationName.
  ///
  /// In en, this message translates to:
  /// **'Organization name'**
  String get organizationName;

  /// No description provided for @nameThisOrganization.
  ///
  /// In en, this message translates to:
  /// **'Name this Organization'**
  String get nameThisOrganization;

  /// No description provided for @registrationLabel.
  ///
  /// In en, this message translates to:
  /// **'Registration'**
  String get registrationLabel;

  /// No description provided for @registrationHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. Kinship Duna, WV Org. ID 167085'**
  String get registrationHint;

  /// No description provided for @whatIsTheMissionYourMembersShare.
  ///
  /// In en, this message translates to:
  /// **'What is the mission your members share?'**
  String get whatIsTheMissionYourMembersShare;

  /// No description provided for @emailLabel.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get emailLabel;

  /// No description provided for @emailHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your email'**
  String get emailHint;

  /// No description provided for @allianceNameLabel.
  ///
  /// In en, this message translates to:
  /// **'Alliance name'**
  String get allianceNameLabel;

  /// No description provided for @allianceNameHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. Conference Planning'**
  String get allianceNameHint;

  /// No description provided for @handleLabel.
  ///
  /// In en, this message translates to:
  /// **'Handle'**
  String get handleLabel;

  /// No description provided for @handleHint.
  ///
  /// In en, this message translates to:
  /// **'conference_planning'**
  String get handleHint;

  /// No description provided for @handleTaken.
  ///
  /// In en, this message translates to:
  /// **'Handle already taken'**
  String get handleTaken;

  /// No description provided for @descriptionLabel.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get descriptionLabel;

  /// No description provided for @allianceDescriptionHint.
  ///
  /// In en, this message translates to:
  /// **'What this Alliance is for.'**
  String get allianceDescriptionHint;

  /// No description provided for @purposeProjectLabel.
  ///
  /// In en, this message translates to:
  /// **'Purpose / Project'**
  String get purposeProjectLabel;

  /// No description provided for @alliancePurposeHint.
  ///
  /// In en, this message translates to:
  /// **'Plan and run Kiduna Live'**
  String get alliancePurposeHint;

  /// No description provided for @visibilityLabel.
  ///
  /// In en, this message translates to:
  /// **'Visibility'**
  String get visibilityLabel;

  /// No description provided for @approvalThresholdLabel.
  ///
  /// In en, this message translates to:
  /// **'Approval Threshold'**
  String get approvalThresholdLabel;

  /// No description provided for @approvalThresholdHint.
  ///
  /// In en, this message translates to:
  /// **'Starts at 1 of 1 — raise it later under \"Approval Threshold\".'**
  String get approvalThresholdHint;

  /// No description provided for @createAllianceAction.
  ///
  /// In en, this message translates to:
  /// **'Create Alliance'**
  String get createAllianceAction;

  /// No description provided for @open.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get open;

  /// No description provided for @design.
  ///
  /// In en, this message translates to:
  /// **'Design'**
  String get design;

  /// No description provided for @refine.
  ///
  /// In en, this message translates to:
  /// **'Refine'**
  String get refine;

  /// No description provided for @portraitDirection.
  ///
  /// In en, this message translates to:
  /// **'Portrait direction'**
  String get portraitDirection;

  /// No description provided for @createPossiblePortraits.
  ///
  /// In en, this message translates to:
  /// **'Create possible portraits'**
  String get createPossiblePortraits;

  /// No description provided for @navigation.
  ///
  /// In en, this message translates to:
  /// **'Navigation'**
  String get navigation;

  /// No description provided for @close.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get close;

  /// No description provided for @collapse.
  ///
  /// In en, this message translates to:
  /// **'Collapse'**
  String get collapse;

  /// No description provided for @minimize.
  ///
  /// In en, this message translates to:
  /// **'Minimize'**
  String get minimize;

  /// No description provided for @expand.
  ///
  /// In en, this message translates to:
  /// **'Expand'**
  String get expand;

  /// No description provided for @resizeFieldAndKi.
  ///
  /// In en, this message translates to:
  /// **'Resize Field and Ki'**
  String get resizeFieldAndKi;

  /// No description provided for @whatYouMostCommonlyCallThem.
  ///
  /// In en, this message translates to:
  /// **'What you most commonly call them'**
  String get whatYouMostCommonlyCallThem;

  /// No description provided for @nameThisRealm.
  ///
  /// In en, this message translates to:
  /// **'Name this Realm'**
  String get nameThisRealm;

  /// No description provided for @whatShouldThisRealmBringIntoBeing.
  ///
  /// In en, this message translates to:
  /// **'What should this Realm bring into being?'**
  String get whatShouldThisRealmBringIntoBeing;

  /// No description provided for @warmConstellation.
  ///
  /// In en, this message translates to:
  /// **'Warm constellation'**
  String get warmConstellation;

  /// No description provided for @celestialGuide.
  ///
  /// In en, this message translates to:
  /// **'Celestial guide'**
  String get celestialGuide;

  /// No description provided for @deepFieldCompanion.
  ///
  /// In en, this message translates to:
  /// **'Deep-field companion'**
  String get deepFieldCompanion;

  /// No description provided for @livingGrove.
  ///
  /// In en, this message translates to:
  /// **'Living grove'**
  String get livingGrove;

  /// No description provided for @radiantBridge.
  ///
  /// In en, this message translates to:
  /// **'Radiant bridge'**
  String get radiantBridge;

  /// No description provided for @celestialBeacon.
  ///
  /// In en, this message translates to:
  /// **'Celestial beacon'**
  String get celestialBeacon;

  /// No description provided for @ancientWarmAlertCelestialEnamelHint.
  ///
  /// In en, this message translates to:
  /// **'Ancient, warm, alert, celestial enamel...'**
  String get ancientWarmAlertCelestialEnamelHint;

  /// No description provided for @focused.
  ///
  /// In en, this message translates to:
  /// **'Focused'**
  String get focused;

  /// No description provided for @dreaming.
  ///
  /// In en, this message translates to:
  /// **'Dreaming'**
  String get dreaming;

  /// No description provided for @engaged.
  ///
  /// In en, this message translates to:
  /// **'Engaged'**
  String get engaged;

  /// No description provided for @openState.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get openState;

  /// No description provided for @invitationMessageFor.
  ///
  /// In en, this message translates to:
  /// **'{name}, Alice has invited you to join Kinship Duna. This is a personal invitation — when you arrive, Ki will know who sent you and help you find your way.'**
  String invitationMessageFor(String name);

  /// No description provided for @realmCreatedTitle.
  ///
  /// In en, this message translates to:
  /// **'{name} created'**
  String realmCreatedTitle(String name);

  /// No description provided for @copiedToClipboard.
  ///
  /// In en, this message translates to:
  /// **'Copied to clipboard'**
  String get copiedToClipboard;

  /// No description provided for @invitationIntendedOnlyFor.
  ///
  /// In en, this message translates to:
  /// **'This invitation is intended only for {name} and expires once used.'**
  String invitationIntendedOnlyFor(String name);

  /// No description provided for @sendThroughKi.
  ///
  /// In en, this message translates to:
  /// **'Send through Ki'**
  String get sendThroughKi;

  /// No description provided for @invitationCopied.
  ///
  /// In en, this message translates to:
  /// **'Invitation copied'**
  String get invitationCopied;

  /// No description provided for @linkCopied.
  ///
  /// In en, this message translates to:
  /// **'Link copied'**
  String get linkCopied;

  /// No description provided for @codeCopied.
  ///
  /// In en, this message translates to:
  /// **'Code copied'**
  String get codeCopied;

  /// No description provided for @yourAllies.
  ///
  /// In en, this message translates to:
  /// **'Your Allies'**
  String get yourAllies;

  /// No description provided for @capacities.
  ///
  /// In en, this message translates to:
  /// **'Capacities'**
  String get capacities;

  /// No description provided for @member.
  ///
  /// In en, this message translates to:
  /// **'Member'**
  String get member;

  /// No description provided for @sevenDays.
  ///
  /// In en, this message translates to:
  /// **'7 days'**
  String get sevenDays;

  /// No description provided for @friend.
  ///
  /// In en, this message translates to:
  /// **'Friend'**
  String get friend;

  /// No description provided for @realmEmblem.
  ///
  /// In en, this message translates to:
  /// **'Realm emblem'**
  String get realmEmblem;

  /// No description provided for @panelClosed.
  ///
  /// In en, this message translates to:
  /// **'{name} panel closed'**
  String panelClosed(String name);

  /// No description provided for @realmPortrait.
  ///
  /// In en, this message translates to:
  /// **'Realm Portrait'**
  String get realmPortrait;

  /// No description provided for @defaultPortraitDescription.
  ///
  /// In en, this message translates to:
  /// **'The default Community Portrait is used until you deliberately create a custom one.'**
  String get defaultPortraitDescription;

  /// No description provided for @askKi.
  ///
  /// In en, this message translates to:
  /// **'Ask Ki'**
  String get askKi;

  /// No description provided for @chooseRoles.
  ///
  /// In en, this message translates to:
  /// **'Choose roles'**
  String get chooseRoles;

  /// No description provided for @requiredField.
  ///
  /// In en, this message translates to:
  /// **'* Required'**
  String get requiredField;

  /// No description provided for @change.
  ///
  /// In en, this message translates to:
  /// **'Change'**
  String get change;

  /// No description provided for @create.
  ///
  /// In en, this message translates to:
  /// **'Create'**
  String get create;

  /// No description provided for @privateHandshakeOptional.
  ///
  /// In en, this message translates to:
  /// **'Private handshake · optional'**
  String get privateHandshakeOptional;

  /// No description provided for @shareASecretWordOrPhrase.
  ///
  /// In en, this message translates to:
  /// **'Share a secret word or phrase.'**
  String get shareASecretWordOrPhrase;

  /// No description provided for @invitationNotesHint.
  ///
  /// In en, this message translates to:
  /// **'Tell Ki about your relationship, the reason for the invitation, and any notes you have that will help Ki welcome your guest and make them feel at home. All notes you include will be marked \"Personal\" and only available to you.'**
  String get invitationNotesHint;

  /// No description provided for @presentName.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get presentName;

  /// No description provided for @savePresentation.
  ///
  /// In en, this message translates to:
  /// **'Save presentation'**
  String get savePresentation;

  /// No description provided for @presentPurposeHint.
  ///
  /// In en, this message translates to:
  /// **'What should {name} make possible?'**
  String presentPurposeHint(String name);

  /// No description provided for @presentPortraitDescription.
  ///
  /// In en, this message translates to:
  /// **'Default {type} Portrait. Create a custom close-range identity whenever it becomes useful.'**
  String presentPortraitDescription(String type);

  /// No description provided for @whatRealmKnowsAndCanDo.
  ///
  /// In en, this message translates to:
  /// **'What {name} knows and what it can do'**
  String whatRealmKnowsAndCanDo(String name);

  /// No description provided for @persona.
  ///
  /// In en, this message translates to:
  /// **'Persona'**
  String get persona;

  /// No description provided for @aliceCatalyst.
  ///
  /// In en, this message translates to:
  /// **'Alice — Catalyst'**
  String get aliceCatalyst;

  /// No description provided for @view.
  ///
  /// In en, this message translates to:
  /// **'View'**
  String get view;

  /// No description provided for @viewNcev.
  ///
  /// In en, this message translates to:
  /// **'T1 · S1 · 1.0 — Newly Created Ecosystem View (NCEV)'**
  String get viewNcev;

  /// No description provided for @viewAev.
  ///
  /// In en, this message translates to:
  /// **'T1 · S1 · 1.1 — Advanced Ecosystem View (AEV)'**
  String get viewAev;

  /// No description provided for @viewSceneRough.
  ///
  /// In en, this message translates to:
  /// **'T2 · S1 · 1.0 — Kinship Duna Scene Rough'**
  String get viewSceneRough;

  /// No description provided for @viewSceneRoughV2.
  ///
  /// In en, this message translates to:
  /// **'T2 · S1 · 1.1 — Kinship Duna Scene Rough v2'**
  String get viewSceneRoughV2;

  /// No description provided for @viewSceneRoughV3.
  ///
  /// In en, this message translates to:
  /// **'T2 · S1 · 1.2 — Kinship Duna Scene Rough v3'**
  String get viewSceneRoughV3;

  /// No description provided for @studioNeedsMoreRoom.
  ///
  /// In en, this message translates to:
  /// **'Studio needs a little more room.'**
  String get studioNeedsMoreRoom;

  /// No description provided for @reopenAtWiderWidth.
  ///
  /// In en, this message translates to:
  /// **'Reopen this View at 1024px or wider.'**
  String get reopenAtWiderWidth;

  /// No description provided for @viewComingSoon.
  ///
  /// In en, this message translates to:
  /// **'This View isn\'t available yet.'**
  String get viewComingSoon;

  /// No description provided for @atlas.
  ///
  /// In en, this message translates to:
  /// **'Atlas'**
  String get atlas;

  /// No description provided for @scene.
  ///
  /// In en, this message translates to:
  /// **'Scene'**
  String get scene;

  /// No description provided for @aevKiWelcome.
  ///
  /// In en, this message translates to:
  /// **'Welcome Alice. Kinship Duna is the current Realm. The Field shows the other Realms visible through this Source’s authority and relationships.'**
  String get aevKiWelcome;

  /// No description provided for @aevKiWelcomeDetail.
  ///
  /// In en, this message translates to:
  /// **'Possible Actions starts with Kinship Duna. Select another Realm to inspect what may be done there.'**
  String get aevKiWelcomeDetail;

  /// No description provided for @whatShouldIDoFirst.
  ///
  /// In en, this message translates to:
  /// **'What should I do first?'**
  String get whatShouldIDoFirst;

  /// No description provided for @tellMeMoreAboutKinshipDuna.
  ///
  /// In en, this message translates to:
  /// **'Tell me more about Kinship Duna.'**
  String get tellMeMoreAboutKinshipDuna;

  /// No description provided for @surface.
  ///
  /// In en, this message translates to:
  /// **'Surface'**
  String get surface;

  /// No description provided for @kidunaWeb.
  ///
  /// In en, this message translates to:
  /// **'Kiduna Web'**
  String get kidunaWeb;

  /// No description provided for @kidunaStudio.
  ///
  /// In en, this message translates to:
  /// **'Kiduna Studio'**
  String get kidunaStudio;

  /// No description provided for @kidunaLive.
  ///
  /// In en, this message translates to:
  /// **'Kiduna Live'**
  String get kidunaLive;

  /// No description provided for @kidunaExpress.
  ///
  /// In en, this message translates to:
  /// **'Kiduna Express'**
  String get kidunaExpress;

  /// No description provided for @kidunaTv.
  ///
  /// In en, this message translates to:
  /// **'Kiduna TV'**
  String get kidunaTv;

  /// No description provided for @comingLater.
  ///
  /// In en, this message translates to:
  /// **'coming later'**
  String get comingLater;

  /// No description provided for @stories.
  ///
  /// In en, this message translates to:
  /// **'Stories'**
  String get stories;

  /// No description provided for @downloadDesignKit.
  ///
  /// In en, this message translates to:
  /// **'Download Studio Design Kit v. 1.7'**
  String get downloadDesignKit;

  /// No description provided for @selectedInTheField.
  ///
  /// In en, this message translates to:
  /// **'Selected in the Field'**
  String get selectedInTheField;

  /// No description provided for @currentRealmLabel.
  ///
  /// In en, this message translates to:
  /// **'Current Realm'**
  String get currentRealmLabel;

  /// No description provided for @yourRole.
  ///
  /// In en, this message translates to:
  /// **'Your role'**
  String get yourRole;

  /// No description provided for @stationedAlly.
  ///
  /// In en, this message translates to:
  /// **'Stationed Ally'**
  String get stationedAlly;

  /// No description provided for @noneStationed.
  ///
  /// In en, this message translates to:
  /// **'None stationed'**
  String get noneStationed;

  /// No description provided for @nestedRealms.
  ///
  /// In en, this message translates to:
  /// **'Nested Realms'**
  String get nestedRealms;

  /// No description provided for @legalStatus.
  ///
  /// In en, this message translates to:
  /// **'Legal status'**
  String get legalStatus;

  /// No description provided for @designFixtureNotYetVerified.
  ///
  /// In en, this message translates to:
  /// **'Design fixture · Not yet verified'**
  String get designFixtureNotYetVerified;

  /// No description provided for @gravityLabel.
  ///
  /// In en, this message translates to:
  /// **'Gravity'**
  String get gravityLabel;

  /// No description provided for @gravityQuiet.
  ///
  /// In en, this message translates to:
  /// **'Quiet'**
  String get gravityQuiet;

  /// No description provided for @gravityAvailable.
  ///
  /// In en, this message translates to:
  /// **'Available'**
  String get gravityAvailable;

  /// No description provided for @gravityRelevant.
  ///
  /// In en, this message translates to:
  /// **'Relevant'**
  String get gravityRelevant;

  /// No description provided for @gravityCentral.
  ///
  /// In en, this message translates to:
  /// **'Central'**
  String get gravityCentral;

  /// No description provided for @gravityVital.
  ///
  /// In en, this message translates to:
  /// **'Vital'**
  String get gravityVital;

  /// No description provided for @gravityQuietMeaning.
  ///
  /// In en, this message translates to:
  /// **'Legitimate context, but not currently relevant'**
  String get gravityQuietMeaning;

  /// No description provided for @gravityAvailableMeaning.
  ///
  /// In en, this message translates to:
  /// **'Related and easy to find'**
  String get gravityAvailableMeaning;

  /// No description provided for @gravityRelevantMeaning.
  ///
  /// In en, this message translates to:
  /// **'Connected to current interests or work'**
  String get gravityRelevantMeaning;

  /// No description provided for @gravityCentralMeaning.
  ///
  /// In en, this message translates to:
  /// **'Directly involved in current responsibility or Focus'**
  String get gravityCentralMeaning;

  /// No description provided for @gravityVitalMeaning.
  ///
  /// In en, this message translates to:
  /// **'Requires sustained awareness or consequential attention'**
  String get gravityVitalMeaning;

  /// No description provided for @whyIsThisHere.
  ///
  /// In en, this message translates to:
  /// **'Why is this here?'**
  String get whyIsThisHere;

  /// No description provided for @enterRealmName.
  ///
  /// In en, this message translates to:
  /// **'Enter {name}'**
  String enterRealmName(String name);

  /// No description provided for @whyRealmIsHere.
  ///
  /// In en, this message translates to:
  /// **'Why {name} is here'**
  String whyRealmIsHere(String name);

  /// No description provided for @gravityIsContextual.
  ///
  /// In en, this message translates to:
  /// **'Its current Gravity is {level} · {name}. Gravity is contextual and inspectable; it is not a score or ranking.'**
  String gravityIsContextual(int level, String name);

  /// No description provided for @inspectRealmInvitation.
  ///
  /// In en, this message translates to:
  /// **'Inspect {name}, adjust its Gravity if useful, or enter it to make its Possible Actions current.'**
  String inspectRealmInvitation(String name);

  /// No description provided for @setGravityFor.
  ///
  /// In en, this message translates to:
  /// **'Set Gravity for {name}'**
  String setGravityFor(String name);

  /// No description provided for @gravityOfRealm.
  ///
  /// In en, this message translates to:
  /// **'Gravity of {name}: {level}'**
  String gravityOfRealm(String name, String level);

  /// No description provided for @navigateToRealm.
  ///
  /// In en, this message translates to:
  /// **'Navigate to {name}'**
  String navigateToRealm(String name);

  /// No description provided for @realmBreadcrumb.
  ///
  /// In en, this message translates to:
  /// **'Realm breadcrumb'**
  String get realmBreadcrumb;

  /// No description provided for @noNestedRealmsVisible.
  ///
  /// In en, this message translates to:
  /// **'No nested Realms visible'**
  String get noNestedRealmsVisible;

  /// No description provided for @useNavigationOrAskKi.
  ///
  /// In en, this message translates to:
  /// **'Use navigation or ask Ki'**
  String get useNavigationOrAskKi;

  /// No description provided for @allyNoneStationed.
  ///
  /// In en, this message translates to:
  /// **'None stationed'**
  String get allyNoneStationed;

  /// No description provided for @wisdom.
  ///
  /// In en, this message translates to:
  /// **'Wisdom'**
  String get wisdom;

  /// No description provided for @whatRealmMayKnow.
  ///
  /// In en, this message translates to:
  /// **'What {name} may know'**
  String whatRealmMayKnow(String name);

  /// No description provided for @presence.
  ///
  /// In en, this message translates to:
  /// **'Presence'**
  String get presence;

  /// No description provided for @howRealmBehaves.
  ///
  /// In en, this message translates to:
  /// **'How {name} behaves'**
  String howRealmBehaves(String name);

  /// No description provided for @connections.
  ///
  /// In en, this message translates to:
  /// **'Connections'**
  String get connections;

  /// No description provided for @accountsRealmMayReach.
  ///
  /// In en, this message translates to:
  /// **'Accounts {name} may reach'**
  String accountsRealmMayReach(String name);

  /// No description provided for @automations.
  ///
  /// In en, this message translates to:
  /// **'Automations'**
  String get automations;

  /// No description provided for @whatKeepsWorkingFor.
  ///
  /// In en, this message translates to:
  /// **'What keeps working for {name}'**
  String whatKeepsWorkingFor(String name);

  /// No description provided for @skills.
  ///
  /// In en, this message translates to:
  /// **'Skills'**
  String get skills;

  /// No description provided for @whatRealmKnowsHowToDo.
  ///
  /// In en, this message translates to:
  /// **'What {name} knows how to do'**
  String whatRealmKnowsHowToDo(String name);

  /// No description provided for @edit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get edit;

  /// No description provided for @remove.
  ///
  /// In en, this message translates to:
  /// **'Remove'**
  String get remove;

  /// No description provided for @download.
  ///
  /// In en, this message translates to:
  /// **'Download'**
  String get download;

  /// No description provided for @delete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete;

  /// No description provided for @connect.
  ///
  /// In en, this message translates to:
  /// **'Connect'**
  String get connect;

  /// No description provided for @disconnect.
  ///
  /// In en, this message translates to:
  /// **'Disconnect'**
  String get disconnect;

  /// No description provided for @connected.
  ///
  /// In en, this message translates to:
  /// **'Connected'**
  String get connected;

  /// No description provided for @uploadFiles.
  ///
  /// In en, this message translates to:
  /// **'Upload files'**
  String get uploadFiles;

  /// No description provided for @uploadSkills.
  ///
  /// In en, this message translates to:
  /// **'Upload Skills'**
  String get uploadSkills;

  /// No description provided for @dropSourcesHere.
  ///
  /// In en, this message translates to:
  /// **'Drop sources here'**
  String get dropSourcesHere;

  /// No description provided for @dropZoneFormats.
  ///
  /// In en, this message translates to:
  /// **'TXT, MD, DOC, DOCX, or PDF. Sources are prepared as Wisdom Drops in Markdown.'**
  String get dropZoneFormats;

  /// No description provided for @createNewWisdomWithKi.
  ///
  /// In en, this message translates to:
  /// **'Create new Wisdom with Ki'**
  String get createNewWisdomWithKi;

  /// No description provided for @developNewPresenceWithKi.
  ///
  /// In en, this message translates to:
  /// **'Develop a new Presence with Ki'**
  String get developNewPresenceWithKi;

  /// No description provided for @createNewSkillWithKi.
  ///
  /// In en, this message translates to:
  /// **'Create a new Skill with Ki'**
  String get createNewSkillWithKi;

  /// No description provided for @currentSystemInstructions.
  ///
  /// In en, this message translates to:
  /// **'Current system instructions'**
  String get currentSystemInstructions;

  /// No description provided for @presenceRequired.
  ///
  /// In en, this message translates to:
  /// **'A Presence is always required. It may be changed or reset, but it cannot be deleted.'**
  String get presenceRequired;

  /// No description provided for @resetToDefault.
  ///
  /// In en, this message translates to:
  /// **'Reset to inherited default'**
  String get resetToDefault;

  /// No description provided for @trigger.
  ///
  /// In en, this message translates to:
  /// **'Trigger'**
  String get trigger;

  /// No description provided for @prepareSelectedAutomations.
  ///
  /// In en, this message translates to:
  /// **'Prepare selected Automations'**
  String get prepareSelectedAutomations;

  /// No description provided for @everyAccountSpecificAndVerified.
  ///
  /// In en, this message translates to:
  /// **'Every account is specific and verified'**
  String get everyAccountSpecificAndVerified;

  /// No description provided for @stopWhenAuthorityExpires.
  ///
  /// In en, this message translates to:
  /// **'Stop when authority expires, the work conflicts, or Alice pauses it.'**
  String get stopWhenAuthorityExpires;

  /// No description provided for @connectedDisconnect.
  ///
  /// In en, this message translates to:
  /// **'Connected · Disconnect'**
  String get connectedDisconnect;

  /// No description provided for @googleDocsOrDriveLink.
  ///
  /// In en, this message translates to:
  /// **'Google Docs or Drive link'**
  String get googleDocsOrDriveLink;

  /// No description provided for @checkAccess.
  ///
  /// In en, this message translates to:
  /// **'Check access'**
  String get checkAccess;

  /// No description provided for @openInGoogleDocs.
  ///
  /// In en, this message translates to:
  /// **'Open in Google Docs'**
  String get openInGoogleDocs;

  /// No description provided for @nSelectedDraft.
  ///
  /// In en, this message translates to:
  /// **'{count} selected · Draft'**
  String nSelectedDraft(int count);

  /// No description provided for @nSkillsAvailable.
  ///
  /// In en, this message translates to:
  /// **'{count} Skills available'**
  String nSkillsAvailable(int count);

  /// No description provided for @skillName.
  ///
  /// In en, this message translates to:
  /// **'Skill name'**
  String get skillName;

  /// No description provided for @nameThisSkill.
  ///
  /// In en, this message translates to:
  /// **'Name this Skill'**
  String get nameThisSkill;

  /// No description provided for @triggerType.
  ///
  /// In en, this message translates to:
  /// **'Trigger type'**
  String get triggerType;

  /// No description provided for @selectTriggerType.
  ///
  /// In en, this message translates to:
  /// **'How should this Skill activate?'**
  String get selectTriggerType;

  /// No description provided for @triggerEvent.
  ///
  /// In en, this message translates to:
  /// **'Event'**
  String get triggerEvent;

  /// No description provided for @triggerEventDescription.
  ///
  /// In en, this message translates to:
  /// **'Reacts when something happens'**
  String get triggerEventDescription;

  /// No description provided for @triggerTime.
  ///
  /// In en, this message translates to:
  /// **'Time'**
  String get triggerTime;

  /// No description provided for @triggerTimeDescription.
  ///
  /// In en, this message translates to:
  /// **'Runs on a schedule'**
  String get triggerTimeDescription;

  /// No description provided for @triggerCondition.
  ///
  /// In en, this message translates to:
  /// **'Condition'**
  String get triggerCondition;

  /// No description provided for @triggerConditionDescription.
  ///
  /// In en, this message translates to:
  /// **'Fires when a threshold is met'**
  String get triggerConditionDescription;

  /// No description provided for @triggerCommand.
  ///
  /// In en, this message translates to:
  /// **'Command'**
  String get triggerCommand;

  /// No description provided for @triggerCommandDescription.
  ///
  /// In en, this message translates to:
  /// **'Activated by a spoken request'**
  String get triggerCommandDescription;

  /// No description provided for @whenLabel.
  ///
  /// In en, this message translates to:
  /// **'When'**
  String get whenLabel;

  /// No description provided for @whenHint.
  ///
  /// In en, this message translates to:
  /// **'Describe when this Skill should activate'**
  String get whenHint;

  /// No description provided for @thenLabel.
  ///
  /// In en, this message translates to:
  /// **'Then'**
  String get thenLabel;

  /// No description provided for @thenHint.
  ///
  /// In en, this message translates to:
  /// **'Describe what this Skill should do'**
  String get thenHint;

  /// No description provided for @toolsLabel.
  ///
  /// In en, this message translates to:
  /// **'Tools'**
  String get toolsLabel;

  /// No description provided for @toolsDescription.
  ///
  /// In en, this message translates to:
  /// **'Select the tools this Skill may use (optional)'**
  String get toolsDescription;

  /// No description provided for @requiresApprovalLabel.
  ///
  /// In en, this message translates to:
  /// **'Requires approval'**
  String get requiresApprovalLabel;

  /// No description provided for @requiresApprovalDescription.
  ///
  /// In en, this message translates to:
  /// **'Ask before executing'**
  String get requiresApprovalDescription;

  /// No description provided for @createSkill.
  ///
  /// In en, this message translates to:
  /// **'Create Skill'**
  String get createSkill;

  /// No description provided for @skillCreated.
  ///
  /// In en, this message translates to:
  /// **'Skill created'**
  String get skillCreated;

  /// No description provided for @skillRemoved.
  ///
  /// In en, this message translates to:
  /// **'Skill removed'**
  String get skillRemoved;

  /// No description provided for @skillNameRequired.
  ///
  /// In en, this message translates to:
  /// **'Skill name is required'**
  String get skillNameRequired;

  /// No description provided for @triggerTypeRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a trigger type'**
  String get triggerTypeRequired;

  /// No description provided for @whenRequired.
  ///
  /// In en, this message translates to:
  /// **'Describe when the Skill should activate'**
  String get whenRequired;

  /// No description provided for @thenRequired.
  ///
  /// In en, this message translates to:
  /// **'Describe what the Skill should do'**
  String get thenRequired;

  /// No description provided for @quickPicks.
  ///
  /// In en, this message translates to:
  /// **'Quick picks'**
  String get quickPicks;

  /// No description provided for @conditionField.
  ///
  /// In en, this message translates to:
  /// **'Field'**
  String get conditionField;

  /// No description provided for @conditionOperator.
  ///
  /// In en, this message translates to:
  /// **'Operator'**
  String get conditionOperator;

  /// No description provided for @conditionThreshold.
  ///
  /// In en, this message translates to:
  /// **'Threshold'**
  String get conditionThreshold;

  /// No description provided for @skillDetail.
  ///
  /// In en, this message translates to:
  /// **'Markdown · Realm scope · Version 1.0'**
  String get skillDetail;

  /// No description provided for @noSkillsCreated.
  ///
  /// In en, this message translates to:
  /// **'No skills were created.'**
  String get noSkillsCreated;

  /// No description provided for @welcomeBack.
  ///
  /// In en, this message translates to:
  /// **'Welcome back'**
  String get welcomeBack;

  /// No description provided for @signInToContinue.
  ///
  /// In en, this message translates to:
  /// **'Sign in to continue to Kiduna'**
  String get signInToContinue;

  /// No description provided for @emailRequired.
  ///
  /// In en, this message translates to:
  /// **'Please enter your email'**
  String get emailRequired;

  /// No description provided for @passwordLabel.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get passwordLabel;

  /// No description provided for @passwordHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your password'**
  String get passwordHint;

  /// No description provided for @passwordRequired.
  ///
  /// In en, this message translates to:
  /// **'Please enter your password'**
  String get passwordRequired;

  /// No description provided for @logIn.
  ///
  /// In en, this message translates to:
  /// **'Log in'**
  String get logIn;

  /// No description provided for @loadingAlly.
  ///
  /// In en, this message translates to:
  /// **'Loading your ally…'**
  String get loadingAlly;

  /// No description provided for @allyLoadFailed.
  ///
  /// In en, this message translates to:
  /// **'Unable to load your ally. Please try again.'**
  String get allyLoadFailed;

  /// No description provided for @chatStreamError.
  ///
  /// In en, this message translates to:
  /// **'Unable to get a response. Please try again.'**
  String get chatStreamError;

  /// No description provided for @chatHistoryLoadFailed.
  ///
  /// In en, this message translates to:
  /// **'Unable to load conversation history.'**
  String get chatHistoryLoadFailed;

  /// No description provided for @kiIsTyping.
  ///
  /// In en, this message translates to:
  /// **'Ki is thinking…'**
  String get kiIsTyping;

  /// No description provided for @retryMessage.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get retryMessage;

  /// No description provided for @kbLoading.
  ///
  /// In en, this message translates to:
  /// **'Loading knowledge base…'**
  String get kbLoading;

  /// No description provided for @kbLoadFailed.
  ///
  /// In en, this message translates to:
  /// **'Unable to load knowledge base.'**
  String get kbLoadFailed;

  /// No description provided for @noWisdomItems.
  ///
  /// In en, this message translates to:
  /// **'No sources added yet.'**
  String get noWisdomItems;

  /// No description provided for @kbItemPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get kbItemPending;

  /// No description provided for @kbItemIngested.
  ///
  /// In en, this message translates to:
  /// **'Ready'**
  String get kbItemIngested;

  /// No description provided for @kbItemFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed'**
  String get kbItemFailed;

  /// No description provided for @nSourcesAvailable.
  ///
  /// In en, this message translates to:
  /// **'{count} sources'**
  String nSourcesAvailable(int count);

  /// No description provided for @uploadingFiles.
  ///
  /// In en, this message translates to:
  /// **'Uploading…'**
  String get uploadingFiles;

  /// No description provided for @importingFromDrive.
  ///
  /// In en, this message translates to:
  /// **'Importing from Drive…'**
  String get importingFromDrive;

  /// No description provided for @driveImportProgress.
  ///
  /// In en, this message translates to:
  /// **'Importing {done} of {total}…'**
  String driveImportProgress(int done, int total);

  /// No description provided for @kbCreateFailed.
  ///
  /// In en, this message translates to:
  /// **'Unable to create knowledge base.'**
  String get kbCreateFailed;

  /// No description provided for @kbDeleteConfirm.
  ///
  /// In en, this message translates to:
  /// **'Delete this source?'**
  String get kbDeleteConfirm;

  /// No description provided for @retry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get retry;

  /// No description provided for @createKnowledgeBase.
  ///
  /// In en, this message translates to:
  /// **'Create Knowledge Base'**
  String get createKnowledgeBase;

  /// No description provided for @kbNameHint.
  ///
  /// In en, this message translates to:
  /// **'Knowledge base name'**
  String get kbNameHint;

  /// No description provided for @kbNameRequired.
  ///
  /// In en, this message translates to:
  /// **'Please enter a name.'**
  String get kbNameRequired;

  /// No description provided for @deleteKnowledgeBase.
  ///
  /// In en, this message translates to:
  /// **'Delete Knowledge Base'**
  String get deleteKnowledgeBase;

  /// No description provided for @deleteKbConfirm.
  ///
  /// In en, this message translates to:
  /// **'This will permanently delete this knowledge base and all its sources.'**
  String get deleteKbConfirm;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @kbSelectedName.
  ///
  /// In en, this message translates to:
  /// **'Knowledge Base: {name}'**
  String kbSelectedName(String name);

  /// No description provided for @kbVisibility.
  ///
  /// In en, this message translates to:
  /// **'Visibility'**
  String get kbVisibility;

  /// No description provided for @kbVisibilityPublic.
  ///
  /// In en, this message translates to:
  /// **'Public'**
  String get kbVisibilityPublic;

  /// No description provided for @kbVisibilityPrivate.
  ///
  /// In en, this message translates to:
  /// **'Private'**
  String get kbVisibilityPrivate;

  /// No description provided for @kbVisibilitySecret.
  ///
  /// In en, this message translates to:
  /// **'Secret'**
  String get kbVisibilitySecret;

  /// No description provided for @kbVisibilityPersonal.
  ///
  /// In en, this message translates to:
  /// **'Personal'**
  String get kbVisibilityPersonal;

  /// No description provided for @googleDrive.
  ///
  /// In en, this message translates to:
  /// **'Google Drive'**
  String get googleDrive;

  /// No description provided for @connectGoogleDrive.
  ///
  /// In en, this message translates to:
  /// **'Connect Google Drive'**
  String get connectGoogleDrive;

  /// No description provided for @driveConnecting.
  ///
  /// In en, this message translates to:
  /// **'Connecting…'**
  String get driveConnecting;

  /// No description provided for @driveSignInFailed.
  ///
  /// In en, this message translates to:
  /// **'Google sign-in failed. Please try again.'**
  String get driveSignInFailed;

  /// No description provided for @driveSignInRequired.
  ///
  /// In en, this message translates to:
  /// **'Please connect Google Drive first.'**
  String get driveSignInRequired;

  /// No description provided for @driveImportAction.
  ///
  /// In en, this message translates to:
  /// **'Import'**
  String get driveImportAction;

  /// No description provided for @drivePasteLinkHint.
  ///
  /// In en, this message translates to:
  /// **'https://drive.google.com/drive/folders/…'**
  String get drivePasteLinkHint;

  /// No description provided for @driveInvalidUrl.
  ///
  /// In en, this message translates to:
  /// **'Invalid Google Drive URL. Paste a file or folder link.'**
  String get driveInvalidUrl;

  /// No description provided for @driveFileNotFound.
  ///
  /// In en, this message translates to:
  /// **'File not found or not accessible.'**
  String get driveFileNotFound;

  /// No description provided for @driveUnsupportedType.
  ///
  /// In en, this message translates to:
  /// **'Unsupported file type. Only PDF, TXT, DOCX, and Google Docs are supported.'**
  String get driveUnsupportedType;

  /// No description provided for @driveFileTooLarge.
  ///
  /// In en, this message translates to:
  /// **'File exceeds the 5 MB size limit.'**
  String get driveFileTooLarge;

  /// No description provided for @driveFilesTooLarge.
  ///
  /// In en, this message translates to:
  /// **'{count} files exceed the 5 MB size limit.'**
  String driveFilesTooLarge(int count);

  /// No description provided for @driveNoSupportedFiles.
  ///
  /// In en, this message translates to:
  /// **'No supported files found. Only PDF, TXT, DOCX, and Google Docs are supported.'**
  String get driveNoSupportedFiles;

  /// No description provided for @presenceStatusInherited.
  ///
  /// In en, this message translates to:
  /// **'Inherited foundation · locally editable'**
  String get presenceStatusInherited;

  /// No description provided for @presenceStatusDraft.
  ///
  /// In en, this message translates to:
  /// **'Local draft · not published'**
  String get presenceStatusDraft;

  /// No description provided for @presenceStatusSaved.
  ///
  /// In en, this message translates to:
  /// **'Published'**
  String get presenceStatusSaved;

  /// No description provided for @presenceStatusSaving.
  ///
  /// In en, this message translates to:
  /// **'Saving…'**
  String get presenceStatusSaving;

  /// No description provided for @presenceStatusReset.
  ///
  /// In en, this message translates to:
  /// **'Reset to default'**
  String get presenceStatusReset;

  /// No description provided for @presenceDefaultPrompt.
  ///
  /// In en, this message translates to:
  /// **'Act in service of {name}’s purpose. Preserve human direction, explain consequential choices, and never infer private intent.'**
  String presenceDefaultPrompt(String name);

  /// No description provided for @presenceSave.
  ///
  /// In en, this message translates to:
  /// **'Save Presence'**
  String get presenceSave;

  /// No description provided for @presenceSaveFailed.
  ///
  /// In en, this message translates to:
  /// **'Unable to save presence. Please try again.'**
  String get presenceSaveFailed;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
