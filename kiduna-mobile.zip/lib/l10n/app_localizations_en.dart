// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'Kiduna';

  @override
  String welcomeTo(String name) {
    return 'Welcome to $name';
  }

  @override
  String get baseProjectReady => 'Base project ready. Start building features.';

  @override
  String get ki => 'Ki';

  @override
  String get inspect => 'Inspect';

  @override
  String get compute => 'Compute';

  @override
  String get openResources => 'Open Resources';

  @override
  String get fieldFocus => 'Field focus';

  @override
  String get possibleActions => 'Possible Actions';

  @override
  String get aFewActionsYouCanTakeNow => 'A few Actions you can take now';

  @override
  String get selectAnyFactToExploreItWithKi =>
      'Select any fact to explore it with Ki.';

  @override
  String get messageKi => 'Message Ki…';

  @override
  String get sendToKi => 'Send to Ki';

  @override
  String get startVoiceInput => 'Start voice input';

  @override
  String get prepareInvitation => 'Prepare invitation';

  @override
  String get nameYouUseForThem => 'Name you use for them';

  @override
  String get expiration => 'Expiration';

  @override
  String get proposedRole => 'Proposed role';

  @override
  String get notes => 'Notes';

  @override
  String get copyLink => 'Copy link';

  @override
  String get copyCode => 'Copy code';

  @override
  String get uniqueLink => 'Unique link';

  @override
  String get kinshipCode => 'Kinship Code';

  @override
  String get personalInvitation => 'Personal invitation';

  @override
  String get realmName => 'Realm name';

  @override
  String get typeLabel => 'Type';

  @override
  String get purpose => 'Purpose';

  @override
  String get createRealmAction => 'Create Realm';

  @override
  String get createOrganizationAction => 'Create Organization';

  @override
  String get creating => 'Creating…';

  @override
  String get organizationName => 'Organization name';

  @override
  String get nameThisOrganization => 'Name this Organization';

  @override
  String get registrationLabel => 'Registration';

  @override
  String get registrationHint => 'e.g. Kinship Duna, WV Org. ID 167085';

  @override
  String get whatIsTheMissionYourMembersShare =>
      'What is the mission your members share?';

  @override
  String get emailLabel => 'Email';

  @override
  String get emailHint => 'Enter your email';

  @override
  String get allianceNameLabel => 'Alliance name';

  @override
  String get allianceNameHint => 'e.g. Conference Planning';

  @override
  String get handleLabel => 'Handle';

  @override
  String get handleHint => 'conference_planning';

  @override
  String get handleTaken => 'Handle already taken';

  @override
  String get descriptionLabel => 'Description';

  @override
  String get allianceDescriptionHint => 'What this Alliance is for.';

  @override
  String get purposeProjectLabel => 'Purpose / Project';

  @override
  String get alliancePurposeHint => 'Plan and run Kiduna Live';

  @override
  String get visibilityLabel => 'Visibility';

  @override
  String get approvalThresholdLabel => 'Approval Threshold';

  @override
  String get approvalThresholdHint =>
      'Starts at 1 of 1 — raise it later under \"Approval Threshold\".';

  @override
  String get createAllianceAction => 'Create Alliance';

  @override
  String get open => 'Open';

  @override
  String get design => 'Design';

  @override
  String get refine => 'Refine';

  @override
  String get portraitDirection => 'Portrait direction';

  @override
  String get createPossiblePortraits => 'Create possible portraits';

  @override
  String get navigation => 'Navigation';

  @override
  String get close => 'Close';

  @override
  String get collapse => 'Collapse';

  @override
  String get minimize => 'Minimize';

  @override
  String get expand => 'Expand';

  @override
  String get resizeFieldAndKi => 'Resize Field and Ki';

  @override
  String get whatYouMostCommonlyCallThem => 'What you most commonly call them';

  @override
  String get nameThisRealm => 'Name this Realm';

  @override
  String get whatShouldThisRealmBringIntoBeing =>
      'What should this Realm bring into being?';

  @override
  String get warmConstellation => 'Warm constellation';

  @override
  String get celestialGuide => 'Celestial guide';

  @override
  String get deepFieldCompanion => 'Deep-field companion';

  @override
  String get livingGrove => 'Living grove';

  @override
  String get radiantBridge => 'Radiant bridge';

  @override
  String get celestialBeacon => 'Celestial beacon';

  @override
  String get ancientWarmAlertCelestialEnamelHint =>
      'Ancient, warm, alert, celestial enamel...';

  @override
  String get focused => 'Focused';

  @override
  String get dreaming => 'Dreaming';

  @override
  String get engaged => 'Engaged';

  @override
  String get openState => 'Open';

  @override
  String invitationMessageFor(String name) {
    return '$name, Alice has invited you to join Kinship Duna. This is a personal invitation — when you arrive, Ki will know who sent you and help you find your way.';
  }

  @override
  String realmCreatedTitle(String name) {
    return '$name created';
  }

  @override
  String get copiedToClipboard => 'Copied to clipboard';

  @override
  String invitationIntendedOnlyFor(String name) {
    return 'This invitation is intended only for $name and expires once used.';
  }

  @override
  String get sendThroughKi => 'Send through Ki';

  @override
  String get invitationCopied => 'Invitation copied';

  @override
  String get linkCopied => 'Link copied';

  @override
  String get codeCopied => 'Code copied';

  @override
  String get yourAllies => 'Your Allies';

  @override
  String get capacities => 'Capacities';

  @override
  String get member => 'Member';

  @override
  String get sevenDays => '7 days';

  @override
  String get friend => 'Friend';

  @override
  String get realmEmblem => 'Realm emblem';

  @override
  String panelClosed(String name) {
    return '$name panel closed';
  }

  @override
  String get realmPortrait => 'Realm Portrait';

  @override
  String get defaultPortraitDescription =>
      'The default Community Portrait is used until you deliberately create a custom one.';

  @override
  String get askKi => 'Ask Ki';

  @override
  String get chooseRoles => 'Choose roles';

  @override
  String get requiredField => '* Required';

  @override
  String get change => 'Change';

  @override
  String get create => 'Create';

  @override
  String get privateHandshakeOptional => 'Private handshake · optional';

  @override
  String get shareASecretWordOrPhrase => 'Share a secret word or phrase.';

  @override
  String get invitationNotesHint =>
      'Tell Ki about your relationship, the reason for the invitation, and any notes you have that will help Ki welcome your guest and make them feel at home. All notes you include will be marked \"Personal\" and only available to you.';

  @override
  String get presentName => 'Name';

  @override
  String get savePresentation => 'Save presentation';

  @override
  String presentPurposeHint(String name) {
    return 'What should $name make possible?';
  }

  @override
  String presentPortraitDescription(String type) {
    return 'Default $type Portrait. Create a custom close-range identity whenever it becomes useful.';
  }

  @override
  String whatRealmKnowsAndCanDo(String name) {
    return 'What $name knows and what it can do';
  }

  @override
  String get persona => 'Persona';

  @override
  String get aliceCatalyst => 'Alice — Catalyst';

  @override
  String get view => 'View';

  @override
  String get viewNcev => 'T1 · S1 · 1.0 — Newly Created Ecosystem View (NCEV)';

  @override
  String get viewAev => 'T1 · S1 · 1.1 — Advanced Ecosystem View (AEV)';

  @override
  String get viewSceneRough => 'T2 · S1 · 1.0 — Kinship Duna Scene Rough';

  @override
  String get viewSceneRoughV2 => 'T2 · S1 · 1.1 — Kinship Duna Scene Rough v2';

  @override
  String get viewSceneRoughV3 => 'T2 · S1 · 1.2 — Kinship Duna Scene Rough v3';

  @override
  String get studioNeedsMoreRoom => 'Studio needs a little more room.';

  @override
  String get reopenAtWiderWidth => 'Reopen this View at 1024px or wider.';

  @override
  String get viewComingSoon => 'This View isn\'t available yet.';

  @override
  String get atlas => 'Atlas';

  @override
  String get scene => 'Scene';

  @override
  String get aevKiWelcome =>
      'Welcome Alice. Kinship Duna is the current Realm. The Field shows the other Realms visible through this Source’s authority and relationships.';

  @override
  String get aevKiWelcomeDetail =>
      'Possible Actions starts with Kinship Duna. Select another Realm to inspect what may be done there.';

  @override
  String get whatShouldIDoFirst => 'What should I do first?';

  @override
  String get tellMeMoreAboutKinshipDuna => 'Tell me more about Kinship Duna.';

  @override
  String get surface => 'Surface';

  @override
  String get kidunaWeb => 'Kiduna Web';

  @override
  String get kidunaStudio => 'Kiduna Studio';

  @override
  String get kidunaLive => 'Kiduna Live';

  @override
  String get kidunaExpress => 'Kiduna Express';

  @override
  String get kidunaTv => 'Kiduna TV';

  @override
  String get comingLater => 'coming later';

  @override
  String get stories => 'Stories';

  @override
  String get downloadDesignKit => 'Download Studio Design Kit v. 1.7';

  @override
  String get selectedInTheField => 'Selected in the Field';

  @override
  String get currentRealmLabel => 'Current Realm';

  @override
  String get yourRole => 'Your role';

  @override
  String get stationedAlly => 'Stationed Ally';

  @override
  String get noneStationed => 'None stationed';

  @override
  String get nestedRealms => 'Nested Realms';

  @override
  String get legalStatus => 'Legal status';

  @override
  String get designFixtureNotYetVerified => 'Design fixture · Not yet verified';

  @override
  String get gravityLabel => 'Gravity';

  @override
  String get gravityQuiet => 'Quiet';

  @override
  String get gravityAvailable => 'Available';

  @override
  String get gravityRelevant => 'Relevant';

  @override
  String get gravityCentral => 'Central';

  @override
  String get gravityVital => 'Vital';

  @override
  String get gravityQuietMeaning =>
      'Legitimate context, but not currently relevant';

  @override
  String get gravityAvailableMeaning => 'Related and easy to find';

  @override
  String get gravityRelevantMeaning => 'Connected to current interests or work';

  @override
  String get gravityCentralMeaning =>
      'Directly involved in current responsibility or Focus';

  @override
  String get gravityVitalMeaning =>
      'Requires sustained awareness or consequential attention';

  @override
  String get whyIsThisHere => 'Why is this here?';

  @override
  String enterRealmName(String name) {
    return 'Enter $name';
  }

  @override
  String whyRealmIsHere(String name) {
    return 'Why $name is here';
  }

  @override
  String gravityIsContextual(int level, String name) {
    return 'Its current Gravity is $level · $name. Gravity is contextual and inspectable; it is not a score or ranking.';
  }

  @override
  String inspectRealmInvitation(String name) {
    return 'Inspect $name, adjust its Gravity if useful, or enter it to make its Possible Actions current.';
  }

  @override
  String setGravityFor(String name) {
    return 'Set Gravity for $name';
  }

  @override
  String gravityOfRealm(String name, String level) {
    return 'Gravity of $name: $level';
  }

  @override
  String navigateToRealm(String name) {
    return 'Navigate to $name';
  }

  @override
  String get realmBreadcrumb => 'Realm breadcrumb';

  @override
  String get noNestedRealmsVisible => 'No nested Realms visible';

  @override
  String get useNavigationOrAskKi => 'Use navigation or ask Ki';

  @override
  String get allyNoneStationed => 'None stationed';

  @override
  String get wisdom => 'Wisdom';

  @override
  String whatRealmMayKnow(String name) {
    return 'What $name may know';
  }

  @override
  String get presence => 'Presence';

  @override
  String howRealmBehaves(String name) {
    return 'How $name behaves';
  }

  @override
  String get connections => 'Connections';

  @override
  String accountsRealmMayReach(String name) {
    return 'Accounts $name may reach';
  }

  @override
  String get automations => 'Automations';

  @override
  String whatKeepsWorkingFor(String name) {
    return 'What keeps working for $name';
  }

  @override
  String get skills => 'Skills';

  @override
  String whatRealmKnowsHowToDo(String name) {
    return 'What $name knows how to do';
  }

  @override
  String get edit => 'Edit';

  @override
  String get remove => 'Remove';

  @override
  String get download => 'Download';

  @override
  String get delete => 'Delete';

  @override
  String get connect => 'Connect';

  @override
  String get disconnect => 'Disconnect';

  @override
  String get connected => 'Connected';

  @override
  String get uploadFiles => 'Upload files';

  @override
  String get uploadSkills => 'Upload Skills';

  @override
  String get dropSourcesHere => 'Drop sources here';

  @override
  String get dropZoneFormats =>
      'TXT, MD, DOC, DOCX, or PDF. Sources are prepared as Wisdom Drops in Markdown.';

  @override
  String get createNewWisdomWithKi => 'Create new Wisdom with Ki';

  @override
  String get developNewPresenceWithKi => 'Develop a new Presence with Ki';

  @override
  String get createNewSkillWithKi => 'Create a new Skill with Ki';

  @override
  String get currentSystemInstructions => 'Current system instructions';

  @override
  String get presenceRequired =>
      'A Presence is always required. It may be changed or reset, but it cannot be deleted.';

  @override
  String get resetToDefault => 'Reset to inherited default';

  @override
  String get trigger => 'Trigger';

  @override
  String get prepareSelectedAutomations => 'Prepare selected Automations';

  @override
  String get everyAccountSpecificAndVerified =>
      'Every account is specific and verified';

  @override
  String get stopWhenAuthorityExpires =>
      'Stop when authority expires, the work conflicts, or Alice pauses it.';

  @override
  String get connectedDisconnect => 'Connected · Disconnect';

  @override
  String get googleDocsOrDriveLink => 'Google Docs or Drive link';

  @override
  String get checkAccess => 'Check access';

  @override
  String get openInGoogleDocs => 'Open in Google Docs';

  @override
  String nSelectedDraft(int count) {
    return '$count selected · Draft';
  }

  @override
  String nSkillsAvailable(int count) {
    return '$count Skills available';
  }

  @override
  String get skillName => 'Skill name';

  @override
  String get nameThisSkill => 'Name this Skill';

  @override
  String get triggerType => 'Trigger type';

  @override
  String get selectTriggerType => 'How should this Skill activate?';

  @override
  String get triggerEvent => 'Event';

  @override
  String get triggerEventDescription => 'Reacts when something happens';

  @override
  String get triggerTime => 'Time';

  @override
  String get triggerTimeDescription => 'Runs on a schedule';

  @override
  String get triggerCondition => 'Condition';

  @override
  String get triggerConditionDescription => 'Fires when a threshold is met';

  @override
  String get triggerCommand => 'Command';

  @override
  String get triggerCommandDescription => 'Activated by a spoken request';

  @override
  String get whenLabel => 'When';

  @override
  String get whenHint => 'Describe when this Skill should activate';

  @override
  String get thenLabel => 'Then';

  @override
  String get thenHint => 'Describe what this Skill should do';

  @override
  String get toolsLabel => 'Tools';

  @override
  String get toolsDescription =>
      'Select the tools this Skill may use (optional)';

  @override
  String get requiresApprovalLabel => 'Requires approval';

  @override
  String get requiresApprovalDescription => 'Ask before executing';

  @override
  String get createSkill => 'Create Skill';

  @override
  String get skillCreated => 'Skill created';

  @override
  String get skillRemoved => 'Skill removed';

  @override
  String get skillNameRequired => 'Skill name is required';

  @override
  String get triggerTypeRequired => 'Select a trigger type';

  @override
  String get whenRequired => 'Describe when the Skill should activate';

  @override
  String get thenRequired => 'Describe what the Skill should do';

  @override
  String get quickPicks => 'Quick picks';

  @override
  String get conditionField => 'Field';

  @override
  String get conditionOperator => 'Operator';

  @override
  String get conditionThreshold => 'Threshold';

  @override
  String get skillDetail => 'Markdown · Realm scope · Version 1.0';

  @override
  String get noSkillsCreated => 'No skills were created.';

  @override
  String get welcomeBack => 'Welcome back';

  @override
  String get signInToContinue => 'Sign in to continue to Kiduna';

  @override
  String get emailRequired => 'Please enter your email';

  @override
  String get passwordLabel => 'Password';

  @override
  String get passwordHint => 'Enter your password';

  @override
  String get passwordRequired => 'Please enter your password';

  @override
  String get logIn => 'Log in';

  @override
  String get loadingAlly => 'Loading your ally…';

  @override
  String get allyLoadFailed => 'Unable to load your ally. Please try again.';

  @override
  String get chatStreamError => 'Unable to get a response. Please try again.';

  @override
  String get chatHistoryLoadFailed => 'Unable to load conversation history.';

  @override
  String get kiIsTyping => 'Ki is thinking…';

  @override
  String get retryMessage => 'Retry';

  @override
  String get kbLoading => 'Loading knowledge base…';

  @override
  String get kbLoadFailed => 'Unable to load knowledge base.';

  @override
  String get noWisdomItems => 'No sources added yet.';

  @override
  String get kbItemPending => 'Pending';

  @override
  String get kbItemIngested => 'Ready';

  @override
  String get kbItemFailed => 'Failed';

  @override
  String nSourcesAvailable(int count) {
    return '$count sources';
  }

  @override
  String get uploadingFiles => 'Uploading…';

  @override
  String get importingFromDrive => 'Importing from Drive…';

  @override
  String driveImportProgress(int done, int total) {
    return 'Importing $done of $total…';
  }

  @override
  String get kbCreateFailed => 'Unable to create knowledge base.';

  @override
  String get kbDeleteConfirm => 'Delete this source?';

  @override
  String get retry => 'Retry';

  @override
  String get createKnowledgeBase => 'Create Knowledge Base';

  @override
  String get kbNameHint => 'Knowledge base name';

  @override
  String get kbNameRequired => 'Please enter a name.';

  @override
  String get deleteKnowledgeBase => 'Delete Knowledge Base';

  @override
  String get deleteKbConfirm =>
      'This will permanently delete this knowledge base and all its sources.';

  @override
  String get cancel => 'Cancel';

  @override
  String kbSelectedName(String name) {
    return 'Knowledge Base: $name';
  }

  @override
  String get kbVisibility => 'Visibility';

  @override
  String get kbVisibilityPublic => 'Public';

  @override
  String get kbVisibilityPrivate => 'Private';

  @override
  String get kbVisibilitySecret => 'Secret';

  @override
  String get kbVisibilityPersonal => 'Personal';

  @override
  String get googleDrive => 'Google Drive';

  @override
  String get connectGoogleDrive => 'Connect Google Drive';

  @override
  String get driveConnecting => 'Connecting…';

  @override
  String get driveSignInFailed => 'Google sign-in failed. Please try again.';

  @override
  String get driveSignInRequired => 'Please connect Google Drive first.';

  @override
  String get driveImportAction => 'Import';

  @override
  String get drivePasteLinkHint => 'https://drive.google.com/drive/folders/…';

  @override
  String get driveInvalidUrl =>
      'Invalid Google Drive URL. Paste a file or folder link.';

  @override
  String get driveFileNotFound => 'File not found or not accessible.';

  @override
  String get driveUnsupportedType =>
      'Unsupported file type. Only PDF, TXT, DOCX, and Google Docs are supported.';

  @override
  String get driveFileTooLarge => 'File exceeds the 5 MB size limit.';

  @override
  String driveFilesTooLarge(int count) {
    return '$count files exceed the 5 MB size limit.';
  }

  @override
  String get driveNoSupportedFiles =>
      'No supported files found. Only PDF, TXT, DOCX, and Google Docs are supported.';

  @override
  String get presenceStatusInherited =>
      'Inherited foundation · locally editable';

  @override
  String get presenceStatusDraft => 'Local draft · not published';

  @override
  String get presenceStatusSaved => 'Published';

  @override
  String get presenceStatusSaving => 'Saving…';

  @override
  String get presenceStatusReset => 'Reset to default';

  @override
  String presenceDefaultPrompt(String name) {
    return 'Act in service of $name’s purpose. Preserve human direction, explain consequential choices, and never infer private intent.';
  }

  @override
  String get presenceSave => 'Save Presence';

  @override
  String get presenceSaveFailed => 'Unable to save presence. Please try again.';
}
